package com.example.hp.ecompetencia_2018.Model;

/**
 * Created by HP on 3/24/2018.
 */

public class model {

    private  int imageno;

    public model(int imageno) {
        this.imageno = imageno;
    }

    public int getImageno() {
        return imageno;
    }

    public void setImageno(int imageno) {
        this.imageno = imageno;
    }
}

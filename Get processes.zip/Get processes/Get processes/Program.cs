﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Get_processes
{
    class Program
    {

        private static DateTime lastTime;
        private static TimeSpan lastTotalProcessorTime;
        private static DateTime curTime;
        private static TimeSpan curTotalProcessorTime;
       
        static void Main(string[] args)
        {
            getProcess();
        }

    private static void getProcess()
        {
            //initializing CSV File
            string filePath = @"C:\Users\Zeeshan\Documents\Visual Studio 2015\Projects\Get processes\def.txt";
            var csv = new StringBuilder();
            var h = "";
            

            //Get process ID and name
            var myID = Process.GetCurrentProcess();
            var query = string.Format("SELECT ParentProcessId FROM Win32_Process");  
            var search = new ManagementObjectSearcher("root\\CIMV2", query);
            var results = search.Get().GetEnumerator();
            while (!Console.KeyAvailable)
            {
                if (!results.MoveNext())
                     throw new Exception("nothing to execute!");
                  
                     var queryObj = results.Current;
                     uint parentId = (uint)queryObj["ParentProcessId"];
                    foreach (Process p in Process.GetProcesses())
                    {
                        if (p.MainWindowTitle.Length > 0)
                        {

                            if (lastTime == null || lastTime == new DateTime())
                            {
                                lastTime = DateTime.Now;
                                lastTotalProcessorTime = p.TotalProcessorTime;
                            }
                            else
                            {
                            /////for calculating Ram/memory of each process
                            Process proc = p;
                            double memsize = 0.00; // memsize in Megabyte
                            PerformanceCounter PC = new PerformanceCounter();
                            PC.CategoryName = "Process";
                            PC.CounterName = "Working Set - Private";
                            PC.InstanceName = proc.ProcessName;
                            memsize = Convert.ToDouble(PC.NextValue()) / 1024000;//(int)(1024);



                            //For Calculating CPU Usage of each Process
                            Console.WriteLine(p.MainWindowTitle.ToString());
                            curTime = DateTime.Now;
                                curTotalProcessorTime = p.TotalProcessorTime;

                                double CPUUsage = (curTotalProcessorTime.TotalMinutes - lastTotalProcessorTime.TotalMinutes) / curTime.Subtract(lastTime).TotalMinutes / Convert.ToDouble(Environment.ProcessorCount);
                                if (CPUUsage < 0 || Double.IsInfinity(CPUUsage))
                                {
                                    CPUUsage = 0.0;
                                };
                                Console.WriteLine("{0} CPU: {1:0.00}%  RAM: {2:0.00}MB", p.ProcessName, (CPUUsage/10000), (memsize));
                            //Storing in CSV
                            double aa = Convert.ToDouble((CPUUsage / 10000)*1.0);
                            h = (p.MainWindowTitle + "," + p.ProcessName + "," + "CPU: " + aa + "," + "RAM: " + Convert.ToDouble(memsize)+"MB" +","+"__________________________________________________________________________________"+ "\n");

                            string res2 = h.Replace(",", Environment.NewLine);
                            csv.AppendLine(res2 );
                            File.WriteAllText(filePath, csv.ToString() + "\n");
                          
                            lastTime = curTime;
                                lastTotalProcessorTime = curTotalProcessorTime;
                        }
                    }
                 
                }
                Thread.Sleep(60000);
                Console.WriteLine("*******************************************************************************");
              
            }

        }
    }

    }

